"use strict";

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var e = React.createElement;

var first = function (_React$Component) {
  _inherits(first, _React$Component);

  function first(props) {
    _classCallCheck(this, first);

    var _this = _possibleConstructorReturn(this, (first.__proto__ || Object.getPrototypeOf(first)).call(this, props));

    var mesh = [];
    for (var i = 0; i < 5; i++) {
      mesh[i] = [];
      for (var j = 0; j < 5; j++) {
        mesh[i][j] = { id: i * 5 + j };
      }
    }
    _this.state = { mesh: mesh };
    return _this;
  }

  _createClass(first, [{
    key: "render",
    value: function render() {
      return React.createElement(
        "div",
        null,
        React.createElement(
          "h1",
          null,
          "asdf"
        ),
        this.state.mesh.map(function (row) {
          return React.createElement(
            "div",
            { className: "row1" },
            row.map(function (cube) {
              return React.createElement("div", { className: "cube1" });
            })
          );
        })
      );
    }
  }]);

  return first;
}(React.Component);

var domContainer = document.querySelector("#root");
ReactDOM.render(e(first), domContainer);
//# sourceMappingURL=1.js.map