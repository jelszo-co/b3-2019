"use strict";

const e = React.createElement;

class first extends React.Component {
  constructor(props) {
    super(props);
    let mesh = [];
    for (let i = 0; i < 5; i++) {
      mesh[i] = [];
      for (let j = 0; j < 5; j++) {
        mesh[i][j] = { id: i * 5 + j };
      }
    }
    this.state = { mesh: mesh };
  }

  render() {
    return (
      <div>
        <h1>asdf</h1>
        {this.state.mesh.map(row => {
          return (
            <div className="row1">
              {row.map(cube => {
                return <div className="cube1"></div>;
              })}
            </div>
          );
        })}
      </div>
    );
  }
}

const domContainer = document.querySelector("#root");
ReactDOM.render(e(first), domContainer);
